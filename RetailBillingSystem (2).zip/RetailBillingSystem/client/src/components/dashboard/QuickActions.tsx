import { useState } from "react";
import { Link } from "wouter";
import { 
  FileText, 
  PackagePlus, 
  UserPlus, 
  BarChart,
  BarChart3,
  TrendingUp,
  Settings,
  HelpCircle
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import BillForm from "@/components/billing/BillForm";
import ProductForm from "@/components/products/ProductForm";
import CustomerForm from "@/components/customers/CustomerForm";
import StockUpdateForm from "@/components/inventory/StockUpdateForm";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const QuickActions = () => {
  const [openDialog, setOpenDialog] = useState<string | null>(null);

  const actions = [
    { 
      name: "New Bill", 
      icon: <FileText className="h-6 w-6" />, 
      bgColor: "bg-primary bg-opacity-10 text-primary",
      action: () => setOpenDialog("bill")
    },
    { 
      name: "Add Product", 
      icon: <PackagePlus className="h-6 w-6" />, 
      bgColor: "bg-secondary bg-opacity-10 text-secondary",
      action: () => setOpenDialog("product")
    },
    { 
      name: "Add Customer", 
      icon: <UserPlus className="h-6 w-6" />, 
      bgColor: "bg-blue-500 bg-opacity-10 text-blue-500",
      action: () => setOpenDialog("customer")
    },
    { 
      name: "Update Stock", 
      icon: <BarChart className="h-6 w-6" />, 
      bgColor: "bg-amber-500 bg-opacity-10 text-amber-500",
      action: () => setOpenDialog("stock")
    },
    {
      name: "Generate Report",
      icon: <BarChart className="h-6 w-6" />, // Using BarChart instead of FileBarChart
      bgColor: "bg-purple-500 bg-opacity-10 text-purple-500",
      href: "/reports"
    },
    {
      name: "View Sales",
      icon: <TrendingUp className="h-6 w-6" />,
      bgColor: "bg-green-500 bg-opacity-10 text-green-500",
      href: "/reports"
    },
    {
      name: "Settings",
      icon: <Settings className="h-6 w-6" />,
      bgColor: "bg-gray-500 bg-opacity-10 text-gray-500",
      href: "/settings"
    },
    {
      name: "Support",
      icon: <HelpCircle className="h-6 w-6" />,
      bgColor: "bg-red-500 bg-opacity-10 text-red-500",
      action: () => window.open('mailto:support@example.com')
    }
  ];

  return (
    <>
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {actions.map((action, index) => (
              <Link href={action.href} key={index}>
                <Button
                  variant="outline"
                  className="flex flex-col items-center justify-center h-auto py-4 border border-gray-200 hover:bg-gray-50"
                  onClick={action.action}
                >
                  <div className={`p-3 rounded-full ${action.bgColor} mb-3`}>
                    {action.icon}
                  </div>
                  <span className="text-sm font-medium text-gray-900">{action.name}</span>
                </Button>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={openDialog === "bill"} onOpenChange={() => setOpenDialog(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Create New Bill</DialogTitle>
          </DialogHeader>
          <BillForm onSuccess={() => setOpenDialog(null)} />
        </DialogContent>
      </Dialog>

      <Dialog open={openDialog === "product"} onOpenChange={() => setOpenDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Product</DialogTitle>
          </DialogHeader>
          <ProductForm onSuccess={() => setOpenDialog(null)} />
        </DialogContent>
      </Dialog>

      <Dialog open={openDialog === "customer"} onOpenChange={() => setOpenDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Customer</DialogTitle>
          </DialogHeader>
          <CustomerForm onSuccess={() => setOpenDialog(null)} />
        </DialogContent>
      </Dialog>

      <Dialog open={openDialog === "stock"} onOpenChange={() => setOpenDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Stock</DialogTitle>
          </DialogHeader>
          <StockUpdateForm onSuccess={() => setOpenDialog(null)} />
        </DialogContent>
      </Dialog>
    </>
  );
};

export default QuickActions;