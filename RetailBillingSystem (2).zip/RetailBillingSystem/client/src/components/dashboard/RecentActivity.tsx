import { useQuery } from "@tanstack/react-query";
import { 
  CheckCircle, 
  Plus, 
  UserPlus, 
  AlertTriangle 
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { ActivityLog } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

const RecentActivity = () => {
  const { data: activities, isLoading } = useQuery<ActivityLog[]>({
    queryKey: ['/api/activity-logs'],
  });

  const getActivityIcon = (activity: ActivityLog) => {
    const { action, entityType } = activity;
    
    if (action.includes('created') || action.includes('added')) {
      if (entityType === 'customer') {
        return (
          <span className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center ring-8 ring-white">
            <UserPlus className="h-5 w-5 text-white" />
          </span>
        );
      }
      return (
        <span className="h-8 w-8 rounded-full bg-primary-light flex items-center justify-center ring-8 ring-white">
          <CheckCircle className="h-5 w-5 text-white" />
        </span>
      );
    }
    
    if (action.includes('updated') || action.includes('Stock')) {
      return (
        <span className="h-8 w-8 rounded-full bg-secondary-light flex items-center justify-center ring-8 ring-white">
          <Plus className="h-5 w-5 text-white" />
        </span>
      );
    }
    
    if (action.includes('alert') || action.includes('low')) {
      return (
        <span className="h-8 w-8 rounded-full bg-red-500 flex items-center justify-center ring-8 ring-white">
          <AlertTriangle className="h-5 w-5 text-white" />
        </span>
      );
    }
    
    return (
      <span className="h-8 w-8 rounded-full bg-gray-500 flex items-center justify-center ring-8 ring-white">
        <CheckCircle className="h-5 w-5 text-white" />
      </span>
    );
  };

  const formatTime = (date: Date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: false });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2 flex flex-row items-center justify-between">
          <CardTitle>Recent Activity</CardTitle>
          <Skeleton className="h-8 w-20" />
        </CardHeader>
        <CardContent>
          <div className="flow-root">
            <ul className="-mb-8">
              {[...Array(4)].map((_, index) => (
                <li key={index}>
                  <div className="relative pb-8">
                    {index < 3 && (
                      <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                    )}
                    <div className="relative flex space-x-3">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                        <div>
                          <Skeleton className="h-4 w-full max-w-md" />
                        </div>
                        <div className="text-right">
                          <Skeleton className="h-4 w-16" />
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle>Recent Activity</CardTitle>
        <Link href="/reports">
          <Button variant="link" className="text-primary h-8">
            View All
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <div className="flow-root">
          <ul className="-mb-8">
            {activities?.map((activity, index) => (
              <li key={activity.id}>
                <div className="relative pb-8">
                  {index < activities.length - 1 && (
                    <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                  )}
                  <div className="relative flex space-x-3">
                    <div>
                      {getActivityIcon(activity)}
                    </div>
                    <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                      <div>
                        <p className="text-sm text-gray-900">{activity.details}</p>
                      </div>
                      <div className="text-right text-sm whitespace-nowrap text-gray-500">
                        {formatTime(activity.createdAt)} ago
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentActivity;
