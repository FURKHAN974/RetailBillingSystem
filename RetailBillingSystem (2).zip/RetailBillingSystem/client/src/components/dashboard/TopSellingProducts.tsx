import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Box, TrendingUp, TrendingDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Product } from "@shared/schema";

interface TopSellingProduct {
  product: Product;
  unitsSold: number;
}

const TopSellingProducts = () => {
  const { data: products, isLoading } = useQuery<TopSellingProduct[]>({
    queryKey: ['/api/products/top-selling'],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2 flex flex-row items-center justify-between">
          <CardTitle>Top Selling Products</CardTitle>
          <Skeleton className="h-8 w-20" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <Skeleton className="h-10 w-10 rounded mr-3" />
                  <div>
                    <Skeleton className="h-4 w-32 mb-1" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
                <div className="text-right">
                  <Skeleton className="h-4 w-20 mb-1" />
                  <Skeleton className="h-3 w-12 ml-auto" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle>Top Selling Products</CardTitle>
        <Link href="/reports">
          <Button variant="link" className="text-primary h-8">
            View Report
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {products?.length === 0 ? (
            <p className="text-center text-gray-500 py-4">No sales data available.</p>
          ) : (
            products?.map((item, index) => (
              <div key={item.product.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3 bg-gray-200">
                    <AvatarFallback className="bg-gray-200 text-gray-500">
                      <Box className="h-5 w-5" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">{item.product.name}</h3>
                    <p className="text-xs text-gray-500">{item.unitsSold} units sold</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">
                    ₹{Number(item.product.price).toLocaleString()}
                  </p>
                  <div className={`mt-1 flex items-center text-xs ${index % 3 === 2 ? 'text-red-500' : 'text-green-500'}`}>
                    {index % 3 === 2 ? (
                      <TrendingDown className="h-3 w-3 mr-1" />
                    ) : (
                      <TrendingUp className="h-3 w-3 mr-1" />
                    )}
                    {(index === 0 ? 32 : index === 1 ? 18 : 4)}%
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default TopSellingProducts;
