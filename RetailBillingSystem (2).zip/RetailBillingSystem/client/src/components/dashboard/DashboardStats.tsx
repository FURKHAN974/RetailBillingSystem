import { useQuery } from "@tanstack/react-query";
import { DollarSign, ShoppingBag, Package, Users, TrendingUp, TrendingDown } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface DashboardStat {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBg: string;
  trend: {
    value: string;
    isUp: boolean;
  };
}

const DashboardStats = () => {
  const { data, isLoading } = useQuery({
    queryKey: ['/api/dashboard/stats'],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[...Array(4)].map((_, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Skeleton className="h-12 w-12 rounded-full mr-4" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-3 w-20" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const stats: DashboardStat[] = [
    {
      title: "Today's Sales",
      value: `₹${data?.todaySales.toLocaleString() || 0}`,
      icon: <DollarSign className="h-6 w-6" />,
      iconBg: "bg-primary bg-opacity-10 text-primary",
      trend: { value: "12% from yesterday", isUp: true }
    },
    {
      title: "New Orders",
      value: data?.newOrders || 0,
      icon: <ShoppingBag className="h-6 w-6" />,
      iconBg: "bg-secondary bg-opacity-10 text-secondary",
      trend: { value: "8% from yesterday", isUp: true }
    },
    {
      title: "Inventory Items",
      value: data?.inventoryItems || 0,
      icon: <Package className="h-6 w-6" />,
      iconBg: "bg-amber-500 bg-opacity-10 text-amber-500",
      trend: { 
        value: `${data?.lowStockItemsCount || 0} items low on stock`, 
        isUp: false 
      }
    },
    {
      title: "Customers",
      value: data?.totalCustomers || 0,
      icon: <Users className="h-6 w-6" />,
      iconBg: "bg-blue-500 bg-opacity-10 text-blue-500",
      trend: { value: "5 new today", isUp: true }
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className={`p-3 rounded-full ${stat.iconBg} mr-4`}>
                {stat.icon}
              </div>
              <div>
                <p className="text-gray-500 text-sm">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
                <p className={`text-xs flex items-center mt-1 ${stat.trend.isUp ? 'text-green-500' : 'text-red-500'}`}>
                  {stat.trend.isUp ? (
                    <TrendingUp className="h-3 w-3 mr-1" />
                  ) : (
                    <TrendingDown className="h-3 w-3 mr-1" />
                  )}
                  {stat.trend.value}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DashboardStats;
