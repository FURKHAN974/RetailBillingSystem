import { useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useReactToPrint } from "react-to-print";
import { Button } from "@/components/ui/button";
import { Printer, MessageSquare } from "lucide-react";
import { BillWithItems, InvoiceTemplate } from "@shared/schema";
import { formatDate } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import QRCode from "react-qr-code";
import { useToast } from "@/hooks/use-toast";
import { useDefaultInvoiceTemplate } from "@/hooks/use-invoice-templates";

interface BillPrintProps {
  billId: number;
  onClose?: () => void;
}

const BillPrint = ({ billId, onClose }: BillPrintProps) => {
  const printRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: bill, isLoading: isBillLoading } = useQuery<BillWithItems>({
    queryKey: [`/api/bills/${billId}`],
  });
  
  // Get the default template for the store
  const { defaultTemplate, isLoading: isTemplateLoading } = useDefaultInvoiceTemplate(
    bill?.storeId ? bill.storeId : undefined
  );

  const handlePrint = useReactToPrint({
    content: () => printRef.current,
    onAfterPrint: () => {
      if (onClose) onClose();
    },
  } as any);

  const isLoading = isBillLoading || isTemplateLoading;
  
  if (isLoading) {
    return (
      <div className="p-4">
        <div className="space-y-4">
          <Skeleton className="h-8 w-40" />
          <Skeleton className="h-6 w-64" />
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-20 w-full" />
        </div>
      </div>
    );
  }

  if (!bill) {
    return (
      <div className="p-4 text-center">
        <p className="text-red-500">Bill not found</p>
        <Button className="mt-4" onClick={onClose}>Close</Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Invoice Preview</h2>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={() => {
              if (bill?.customer?.phone) {
                fetch(`/api/bills/${billId}/send-sms`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' }
                })
                  .then(async res => {
                    if (res.ok) {
                      toast({
                        title: "SMS Sent",
                        description: `Invoice SMS sent to ${bill.customer.phone}`,
                      });
                    } else {
                      // Parse the error response to get detailed message
                      let errorMessage = "Please try again later";
                      try {
                        const errorData = await res.json();
                        if (errorData.error) {
                          errorMessage = errorData.error;
                        } else if (errorData.message) {
                          errorMessage = errorData.message;
                        }
                      } catch (e) {
                        // If JSON parsing fails, use the default message
                      }
                      
                      toast({
                        title: "Failed to send SMS",
                        description: errorMessage,
                        variant: "destructive"
                      });
                    }
                  })
                  .catch(err => {
                    toast({
                      title: "Error",
                      description: err.message,
                      variant: "destructive"
                    });
                  });
              } else {
                toast({
                  title: "Cannot send SMS",
                  description: "Customer has no phone number",
                  variant: "destructive"
                });
              }
            }}
            disabled={!bill?.customer?.phone}
          >
            <MessageSquare className="mr-2 h-4 w-4" />
            Send SMS
          </Button>
          <Button onClick={handlePrint}>
            <Printer className="mr-2 h-4 w-4" />
            Print Invoice
          </Button>
        </div>
      </div>

      <div 
        ref={printRef} 
        className="p-3 bg-white text-sm"
        style={defaultTemplate?.styles ? {
          fontFamily: (defaultTemplate.styles as any).fontFamily || 'inherit',
          fontSize: '12px',
          color: (defaultTemplate.styles as any).bodyTextColor || 'inherit',
          lineHeight: '1.2',
        } : {}}
      >
        {/* Header Section with Logo and Store Info */}
        <div className="mb-8 text-center">
          {defaultTemplate?.logoUrl && (
            <img 
              src={defaultTemplate.logoUrl} 
              alt="Store logo" 
              className="mx-auto mb-2 max-h-16" 
            />
          )}
          
          {/* Custom Header HTML */}
          {defaultTemplate?.headerHtml ? (
            <div 
              dangerouslySetInnerHTML={{ __html: defaultTemplate.headerHtml }}
              style={{
                color: defaultTemplate.styles ? (defaultTemplate.styles as any).headerTextColor : 'inherit'
              }}
            />
          ) : (
            <>
              <h1 className="text-lg font-bold">{bill.store?.name || "RetailPro"}</h1>
              <p className="text-sm">Invoice Receipt</p>
            </>
          )}
        </div>

        {/* Customer and Invoice Details */}
        <div 
          className="flex justify-between mb-8"
          style={{
            borderColor: defaultTemplate?.styles ? (defaultTemplate.styles as any).borderColor : '#e5e7eb',
            borderWidth: defaultTemplate?.styles ? (defaultTemplate.styles as any).borderWidth : '1px',
            borderRadius: defaultTemplate?.styles ? (defaultTemplate.styles as any).borderRadius : '0.375rem',
          }}
        >
          <div>
            <h2 className="font-bold mb-1">Invoice To:</h2>
            <p>{bill.customer?.name || "Walk-in Customer"}</p>
            {bill.customer?.address && <p>{bill.customer.address}</p>}
            {bill.customer?.phone && <p>Phone: {bill.customer.phone}</p>}
            {bill.customer?.email && <p>Email: {bill.customer.email}</p>}
          </div>
          <div className="text-right">
            <h2 className="font-bold mb-1">Invoice Details:</h2>
            <p>Invoice Number: <span className="font-medium">{bill.billNumber}</span></p>
            <p>Date: <span className="font-medium">{formatDate(bill.createdAt)}</span></p>
            <p>Status: <span className="font-medium capitalize">{bill.status}</span></p>
          </div>
        </div>

        {/* Items Table */}
        <div className="overflow-x-auto mb-8">
          <table 
            className="min-w-full"
            style={{
              borderCollapse: 'collapse',
              borderColor: defaultTemplate?.styles ? (defaultTemplate.styles as any).borderColor : '#e5e7eb',
            }}
          >
            <thead>
              <tr style={{
                backgroundColor: defaultTemplate?.styles ? (defaultTemplate.styles as any).primaryColor : '#f3f4f6',
                color: defaultTemplate?.styles ? (defaultTemplate.styles as any).headerTextColor : 'inherit',
              }}>
                <th className="py-1 px-2 text-left text-xs">Item</th>
                <th className="py-1 px-2 text-right text-xs">Price</th>
                <th className="py-1 px-2 text-right text-xs">Qty</th>
                <th className="py-1 px-2 text-right text-xs">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y" style={{
              borderColor: defaultTemplate?.styles ? (defaultTemplate.styles as any).borderColor : '#e5e7eb',
            }}>
              {bill.items.map((item, index) => (
                <tr key={index}>
                  <td className="py-3 px-4">{item.product.name}</td>
                  <td className="py-3 px-4 text-right">₹{Number(item.price).toLocaleString()}</td>
                  <td className="py-3 px-4 text-right">{item.quantity}</td>
                  <td className="py-3 px-4 text-right">₹{Number(item.total).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totals Section */}
        <div className="flex justify-end mb-8">
          <div className="w-64">
            <div className="flex justify-between py-2">
              <span className="font-medium">Subtotal:</span>
              <span>₹{Number(bill.subtotal).toLocaleString()}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="font-medium">Tax (18%):</span>
              <span>₹{Number(bill.tax).toLocaleString()}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="font-medium">Discount:</span>
              <span>₹{Number(bill.discount).toLocaleString()}</span>
            </div>
            <div className="flex justify-between py-2 font-bold" style={{
              borderTopWidth: '1px',
              borderTopStyle: 'solid',
              borderColor: defaultTemplate?.styles ? (defaultTemplate.styles as any).borderColor : '#e5e7eb',
            }}>
              <span>Total:</span>
              <span>₹{Number(bill.total).toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Notes Section */}
        {bill.notes && (
          <div className="mb-8">
            <h3 className="font-bold mb-1">Notes:</h3>
            <p>{bill.notes}</p>
          </div>
        )}
        
        {/* QR Code for UPI Payment */}
        {bill.upiId && (
          <div className="mb-8 flex flex-col items-center">
            <h3 className="font-bold mb-2">Scan to Pay via UPI:</h3>
            <div 
              className="p-4 rounded-lg mb-2"
              style={{
                backgroundColor: 'white',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: defaultTemplate?.styles ? (defaultTemplate.styles as any).borderColor : '#e5e7eb',
              }}
            >
              <QRCode
                value={`upi://pay?pa=${bill.upiId}&pn=${bill.store?.name || "RetailPro"}&am=${bill.total}&cu=INR&tn=Bill-${bill.billNumber}`}
                size={150}
                level="H"
              />
            </div>
            <p className="text-sm">UPI ID: {bill.upiId}</p>
          </div>
        )}

        {/* Footer Section */}
        <div 
          className="text-center text-sm mt-16"
          style={{
            color: defaultTemplate?.styles ? (defaultTemplate.styles as any).footerTextColor : '#6b7280',
          }}
        >
          {defaultTemplate?.footerHtml ? (
            <div dangerouslySetInnerHTML={{ __html: defaultTemplate.footerHtml }} />
          ) : (
            <>
              <p>Thank you for your business!</p>
              <p>{bill.store?.name || "RetailPro"} Billing System</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default BillPrint;
