import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertBillSchema, insertBillItemSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X, Plus, Trash2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";


const formSchema = z.object({
  customerId: z.coerce.number().optional(),
  billNumber: z.string(),
  subtotal: z.coerce.number(),
  tax: z.coerce.number(),
  discount: z.coerce.number(),
  total: z.coerce.number(),
  status: z.string(),
  notes: z.string().optional(),
  upiId: z.string().optional(),
  paymentMethod: z.string(),
});

interface ProductItem {
  productId: number;
  name: string;
  price: number;
  quantity: number;
  total: number;
}

interface BillFormProps {
  onSuccess?: () => void;
}

const BillForm = ({ onSuccess }: BillFormProps) => {
  const [selectedProducts, setSelectedProducts] = useState<ProductItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [customerPhone, setCustomerPhone] = useState("");
  const [salesPerson, setSalesPerson] = useState("");
  const [barcodeInput, setBarcodeInput] = useState("");
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F4') {
        const person = prompt("Enter sales person name:");
        if (person) setSalesPerson(person);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (barcodeInput) {
      timeout = setTimeout(() => {
        const product = products?.find(p => p.sku === barcodeInput);
        if (product) {
          handleProductSelect(product.id.toString());
        }
        setBarcodeInput("");
      }, 100);
    }
    return () => clearTimeout(timeout);
  }, [barcodeInput]);

  const handleCustomerLookup = async (phone: string) => {
    const customer = customers?.find(c => c.phone === phone);
    if (customer) {
      setSelectedCustomerId(customer.id);
      toast({
        title: "Customer found",
        description: `Welcome back ${customer.name}!`,
      });
    } else {
      const name = prompt("New customer! Please enter name:");
      if (name) {
        try {
          const newCustomer = await apiRequest("POST", "/api/customers", {
            name,
            phone: customerPhone,
          });
          setSelectedCustomerId(newCustomer.id);
          toast({
            title: "Success",
            description: "Customer registered successfully!",
          });
          queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to register customer",
            variant: "destructive",
          });
        }
      }
    }
  };

  const { data: customers = [], isLoading: isLoadingCustomers } = useQuery<any[]>({
    queryKey: ['/api/customers'],
  });

  const { data: products = [], isLoading: isLoadingProducts } = useQuery<any[]>({
    queryKey: ['/api/products'],
  });

  const generateBillNumber = () => {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');

    return `INV-${year}${month}${day}-${random}`;
  };

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      billNumber: generateBillNumber(),
      subtotal: 0,
      tax: 0,
      discount: 0,
      total: 0,
      status: "paid",
      notes: "",
      upiId: "",
      paymentMethod: "cash",
    },
  });

  useEffect(() => {
    const subtotal = selectedProducts.reduce((sum, item) => sum + item.total, 0);
    const taxRate = 0.18;
    const tax = subtotal * taxRate;
    const discount = parseFloat(form.getValues("discount") as any) || 0;
    const total = subtotal + tax - discount;

    form.setValue("subtotal", subtotal);
    form.setValue("tax", tax);
    form.setValue("total", total);
  }, [selectedProducts, form]);

  const createBillMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/bills", data);
    },
    onSuccess: () => {
      toast({
        title: "Bill created",
        description: "The bill has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bills'] });
      queryClient.invalidateQueries({ queryKey: ['/api/bills/recent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      form.reset();
      setSelectedProducts([]);
      setSelectedCustomerId(null);
      form.setValue("billNumber", generateBillNumber());
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create bill: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: z.infer<typeof formSchema>) => {
    if (selectedProducts.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one product to the bill.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const items = selectedProducts.map(product => ({
        productId: product.productId,
        quantity: product.quantity,
        price: product.price.toString(),
        total: product.total.toString()
      }));

      if (selectedCustomerId) {
        data.customerId = selectedCustomerId;
      }

      const billWithStringValues = {
        ...data,
        subtotal: data.subtotal.toString(),
        tax: data.tax.toString(),
        discount: data.discount.toString(),
        total: data.total.toString()
      };

      const billData = {
        bill: billWithStringValues,
        items: items
      };

      await createBillMutation.mutateAsync(billData);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddProduct = () => {
    const productSelectTrigger = document.getElementById("product-select") as HTMLElement;
    productSelectTrigger?.click();
  };

  const handleProductSelect = (productId: string) => {
    const product = products.find(p => p.id === parseInt(productId));

    if (product) {
      const existingProductIndex = selectedProducts.findIndex(p => p.productId === product.id);

      if (existingProductIndex >= 0) {
        const updatedProducts = [...selectedProducts];
        const item = updatedProducts[existingProductIndex];
        item.quantity += 1;
        item.total = item.price * item.quantity;
        setSelectedProducts(updatedProducts);
      } else {
        setSelectedProducts([...selectedProducts, {
          productId: product.id,
          name: product.name,
          price: parseFloat(product.price as any),
          quantity: 1,
          total: parseFloat(product.price as any)
        }]);
      }

      setTimeout(() => {
        const productSelectElement = document.getElementById("product-select") as HTMLSelectElement;
        if (productSelectElement) productSelectElement.value = "";
      }, 100);
    }
  };

  const handleQuantityChange = (index: number, quantity: number) => {
    if (quantity < 1) quantity = 1;

    const updatedProducts = [...selectedProducts];
    updatedProducts[index].quantity = quantity;
    updatedProducts[index].total = updatedProducts[index].price * quantity;
    setSelectedProducts(updatedProducts);
  };

  const handleRemoveProduct = (index: number) => {
    const updatedProducts = [...selectedProducts];
    updatedProducts.splice(index, 1);
    setSelectedProducts(updatedProducts);
  };

  const handleDiscountChange = (value: number) => {
    form.setValue("discount", value);

    const subtotal = form.getValues("subtotal") as number;
    const tax = form.getValues("tax") as number;
    form.setValue("total", subtotal + tax - value);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <FormItem>
            <FormLabel>Customer</FormLabel>
            <Select 
              onValueChange={(value) => setSelectedCustomerId(parseInt(value))}
              value={selectedCustomerId?.toString() || ""}
            >
              <SelectTrigger className="h-10">
                <SelectValue placeholder="Search customer..." />
              </SelectTrigger>
              <SelectContent>
                {isLoadingCustomers ? (
                  <SelectItem value="loading" disabled>Loading customers...</SelectItem>
                ) : customers?.length === 0 ? (
                  <SelectItem value="none" disabled>No customers found</SelectItem>
                ) : (
                  customers?.map(customer => (
                    <SelectItem key={customer.id} value={customer.id.toString()}>
                      {customer.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </FormItem>

          <FormField
            control={form.control}
            name="billNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bill Number</FormLabel>
                <FormControl>
                  <Input {...field} disabled className="bg-gray-100" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                      <SelectItem value="returned">Returned</SelectItem>
                      <SelectItem value="exchanged">Exchanged</SelectItem>
                      <SelectItem value="creditnote">Credit Note</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Method</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="upi">UPI</SelectItem>
                      <SelectItem value="card">Card</SelectItem>
                      <SelectItem value="opt">OPT (Online Payment)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        <div className="mt-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-md font-medium">Products</h3>
            <div className="flex items-center space-x-2">
              <Select onValueChange={handleProductSelect}>
                <SelectTrigger className="h-9 w-[250px]" id="product-select">
                  <SelectValue placeholder="Select product to add..." />
                </SelectTrigger>
                <SelectContent>
                  {isLoadingProducts ? (
                    <SelectItem value="loading" disabled>Loading products...</SelectItem>
                  ) : products?.length === 0 ? (
                    <SelectItem value="none" disabled>No products found</SelectItem>
                  ) : (
                    products?.map(product => (
                      <SelectItem key={product.id} value={product.id.toString()}>
                        {product.name} - ₹{parseFloat(product.price as any).toLocaleString()}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>

              <Button 
                type="button" 
                size="sm" 
                onClick={handleAddProduct}
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Product
              </Button>
            </div>
          </div>

          <div className="border rounded-md overflow-hidden">
            <Table className="text-sm">
              <TableHeader>
                <TableRow>
                  <TableHead className="py-1 text-xs">Product</TableHead>
                  <TableHead className="text-right py-1 text-xs">Price</TableHead>
                  <TableHead className="text-right py-1 text-xs">Qty</TableHead>
                  <TableHead className="text-right py-1 text-xs">Total</TableHead>
                  <TableHead className="text-center w-12 py-1"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedProducts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                      No products added to the bill yet
                    </TableCell>
                  </TableRow>
                ) : (
                  selectedProducts.map((product, index) => (
                    <TableRow key={index} className="h-10">
                      <TableCell className="py-1">{product.name}</TableCell>
                      <TableCell className="text-right py-1">₹{product.price.toLocaleString()}</TableCell>
                      <TableCell className="text-right py-1">
                        <Input
                          type="number"
                          value={product.quantity}
                          onChange={(e) => handleQuantityChange(index, parseInt(e.target.value))}
                          min="1"
                          className="w-14 h-7 text-right ml-auto p-1"
                        />
                      </TableCell>
                      <TableCell className="text-right py-1 font-medium">
                        ₹{product.total.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-center py-1">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveProduct(index)}
                          className="h-6 w-6 p-0"
                        >
                          <Trash2 className="h-3 w-3 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="upiId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reference/UPI</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      placeholder={form.getValues("status") === "returned" || form.getValues("status") === "exchanged" ? "Original Bill Number" : "UPI ID"} 
                      className="text-sm"
                    />
                  </FormControl>
                  <FormDescription className="text-xs">
                    {form.getValues("status") === "returned" || form.getValues("status") === "exchanged" 
                      ? "Enter original bill number for return/exchange" 
                      : "UPI ID for QR code generation"}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Add notes for this bill" 
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div>
            <Card className="bg-gray-50 p-3 rounded-md">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Subtotal:</span>
                  <span className="text-gray-900">₹{form.getValues("subtotal").toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Tax (18%):</span>
                  <span className="text-gray-900">₹{form.getValues("tax").toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Discount:</span>
                  <Input
                    type="number"
                    min="0"
                    step="1"
                    className="w-16 h-6 text-right text-sm p-1"
                    value={form.getValues("discount")}
                    onChange={(e) => handleDiscountChange(parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="flex justify-between items-center font-bold">
                  <span>Total:</span>
                  <span className="text-lg">₹{form.getValues("total").toLocaleString()}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>

        <div className="flex justify-between items-center pt-4">
          <div className="flex items-center space-x-4">
            <Input
              placeholder="Enter barcode/SKU"
              value={barcodeInput}
              onChange={(e) => setBarcodeInput(e.target.value)}
              className="w-40"
            />
            <div className="text-sm text-gray-500">
              Press F4 for sales person: {salesPerson || 'Not set'}
            </div>
          </div>
          <div className="flex space-x-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => {
                form.reset();
                setSelectedProducts([]);
                if (onSuccess) onSuccess();
              }}
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={() => setShowPaymentDialog(true)}
              disabled={selectedProducts.length === 0}
            >
              End Bill
            </Button>
          </div>
        </div>

        <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Complete Payment</DialogTitle>
              <DialogDescription>
                Please complete the payment to generate the bill
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <FormField
                control={form.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Method</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="upi">UPI</SelectItem>
                        <SelectItem value="card">Card</SelectItem>
                        <SelectItem value="opt">OPT (Online Payment)</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              <div className="text-xl font-bold text-center">
                Total Amount: ₹{form.getValues("total").toLocaleString()}
              </div>
              <Button 
                className="w-full" 
                onClick={form.handleSubmit(onSubmit)}
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Processing...' : 'Complete Payment'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </form>
    </Form>
  );
};

export default BillForm;