
import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  BarChart3,
  ClipboardList,
  Package,
  Receipt,
  Settings,
  Users,
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const menuItems = [
    {
      href: "/",
      icon: BarChart3,
      label: "Dashboard",
      adminOnly: true,
    },
    {
      href: "/billing",
      icon: Receipt,
      label: "Billing",
      adminOnly: false,
    },
    {
      href: "/products",
      icon: Package,
      label: "Products",
      adminOnly: true,
    },
    {
      href: "/customers",
      icon: Users,
      label: "Customers",
      adminOnly: true,
    },
    {
      href: "/inventory",
      icon: ClipboardList,
      label: "Inventory",
      adminOnly: true,
    },
    {
      href: "/settings",
      icon: Settings,
      label: "Settings",
      adminOnly: true,
    },
  ];

  return (
    <aside className="flex h-screen w-full flex-col px-4 py-8 border-r bg-card shadow-lg">
      <div className="flex items-center gap-2 px-2">
        <span className="text-2xl font-semibold">Retail System</span>
      </div>
      
      <nav className="flex-1 space-y-2 mt-8">
        {menuItems.map((item) => {
          if (!isAdmin && item.adminOnly) return null;
          
          return (
            <Link 
              key={item.href} 
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-gray-500 transition-all hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50",
                location === item.href &&
                  "bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-gray-50"
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
