import ProductList from "@/components/products/ProductList";

const Products = () => {
  return (
    <div>
      <ProductList />
    </div>
  );
};

export default Products;
