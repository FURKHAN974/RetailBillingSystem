import InventoryList from "@/components/inventory/InventoryList";

const Inventory = () => {
  return (
    <div>
      <InventoryList />
    </div>
  );
};

export default Inventory;
