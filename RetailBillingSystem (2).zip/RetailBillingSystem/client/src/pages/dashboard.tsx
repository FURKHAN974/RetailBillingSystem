import DashboardStats from "@/components/dashboard/DashboardStats";
import RecentTransactions from "@/components/dashboard/RecentTransactions";
import LowStockInventory from "@/components/dashboard/LowStockInventory";
import TopSellingProducts from "@/components/dashboard/TopSellingProducts";
import QuickActions from "@/components/dashboard/QuickActions";
import RecentActivity from "@/components/dashboard/RecentActivity";

const Dashboard = () => {
  return (
    <div className="container mx-auto p-4 max-w-7xl">
      <DashboardStats />
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 space-y-6">
          <QuickActions />
          <RecentTransactions />
          <RecentActivity />
        </div>
        <div className="lg:col-span-4 space-y-6">
          <TopSellingProducts />
          <LowStockInventory />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;