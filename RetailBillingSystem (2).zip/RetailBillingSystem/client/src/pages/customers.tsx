import CustomerList from "@/components/customers/CustomerList";

const Customers = () => {
  return (
    <div>
      <CustomerList />
    </div>
  );
};

export default Customers;
